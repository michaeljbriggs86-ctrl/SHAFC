Shooters Hill Team Tracker Android Cloud v2.0.31

Android package
  com.shootershill.valiants

Version
  2.0.31 (versionCode 2031)

Build
  The GitHub Action extracts this ZIP and runs:
    gradle :app:assembleDebug

v2.0.31 highlights
- Completed non-league matches can be edited, with Friendly / Tournament classification.
- U8-U11 rolling-sub attendance uses Present / Not present only.
- U15-and-below player accounts are supported as read-only profiles, with only their own match availability editable.
- Coaches can create a player invite tied to a specific registered squad player.
- Player and linked parent accounts share one availability response per player/fixture, preventing duplicates.
- Direct Inbox messaging is removed from the app and authenticated access to club_messages is revoked; club announcements/notices remain the communication route.
- Light / Dark / System appearance selector added.
- Same-age Selkent opponent selector backed by public.selkent_team_directory.
- The app invokes the authenticated selkent-teams-sync Edge Function if the opponent directory is empty.
- U8X/U10X/etc. teams are retained within their numeric age group and labelled distinctly.
- Parent PIN is chosen immediately after invite use and saved to the account while approval is pending; PIN login stays blocked until approval.
- Returning parent/player PIN login uses the full Shooters Hill team dropdown.

Previous retained features
- Club Admin + Coach dual-role mode.
- Secure parent PIN reset.
- Coach-controlled parent-player links.
- RSVP-driven matchday squad and fixture-specific tactics.
- Fixture change/reconfirmation workflow and Matchday Dashboard.
- Club announcements and read acknowledgement.
- Match attendance.
- Grouped Admin health dashboard.
- U12+ published league results/table rule.
- Mini-soccer manual score entry.
- Dynamic stat-card layout, contribution table and removable awards.
