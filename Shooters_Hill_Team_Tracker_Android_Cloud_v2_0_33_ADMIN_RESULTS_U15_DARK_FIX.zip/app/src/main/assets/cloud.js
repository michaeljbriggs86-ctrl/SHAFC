(function(){
  'use strict';

  const cfg = window.VALIANTS_CLOUD || {};
  const SESSION_KEY = 'shooters_hill_cloud_session_v2';
  const INVITE_KEY = 'shooters_hill_pending_invite_v2';
  const ACTIVE_TEAM_KEY = 'shooters_hill_admin_active_team_v2';
  const VERIFY_EMAIL_KEY = 'shooters_hill_verify_email_v2';
  const TEAM_DIRECTORY_CACHE_KEY = 'shooters_hill_team_directory_cache_v1';
  const TEAM_STATE_CACHE_PREFIX = 'shooters_hill_team_state_cache_v1_';
  const INVITE_LOCK_KEY = 'shooters_hill_invite_lock_v1';
  const PENDING_PARENT_PIN_KEY = 'shooters_hill_pending_parent_pin_v1';
  const TEST_MODE_KEY = 'shooters_hill_debug_test_mode_v1';
  const PIN_TEAM_OPTIONS = ['U8 Cannons','U8 Green','U9 Gunners','U9 Valiants','U10 Royals','U10 Vikings','U11 Jaguars','U12 Archers','U12 Cannons','U12 Lions','U13 Vipers','U14 Cannons','U14 Lions','U15 Cannons','U15 Romans'];
  const AUTH_REDIRECT = 'shootershilltracker://auth-callback';
  const INITIAL_AUTH_CALLBACK = new URLSearchParams(location.search).get('auth_callback') || '';
  let initialAuthCallbackHandled = false;
  let session = null;
  let context = null;
  let visibleTeams = [];
  let activeTeam = null;
  let activeRevision = -1;
  let lastRemoteUpdatedAt = '';
  let saveTimer = null;
  let saving = false;
  let pendingState = null;
  let pollTimer = null;
  let hooks = {};
  const TEST_TEAM={id:'debug-u9-valiants',club_id:'debug-club',name:'Valiants',age_group:9,division:'Under 9D Navy',season:'2026/27',selkent_label:'Shooters Hill Valiants',league_name:'Shooters Hill Valiants',active:true};

  function debugBuild(){try{return !!window.ValiantsNative?.isDebugBuild?.();}catch{return false;}}
  function testModeActive(){return debugBuild()&&localStorage.getItem(TEST_MODE_KEY)==='coach';}

  function configured(){
    return cfg.enabled !== false && /^https:\/\/.+\.supabase\.co$/i.test(String(cfg.url||'')) &&
      String(cfg.anonKey||'').length > 40 && !String(cfg.anonKey).includes('YOUR-');
  }
  function base(){ return String(cfg.url||'').replace(/\/$/,''); }
  function emitStatus(text, type='info'){
    const el=document.getElementById('cloud-sync-status');
    if(el){el.textContent=text;el.dataset.state=type;}
    window.dispatchEvent(new CustomEvent('valiants-cloud-status',{detail:{text,type}}));
  }
  function saveSession(s){
    session=s||null;
    if(session) localStorage.setItem(SESSION_KEY,JSON.stringify(session));
    else localStorage.removeItem(SESSION_KEY);
  }
  function loadSession(){
    try{return JSON.parse(localStorage.getItem(SESSION_KEY)||'null');}catch{return null;}
  }
  function cachedTeams(){try{const x=JSON.parse(localStorage.getItem(TEAM_DIRECTORY_CACHE_KEY)||'null');return Array.isArray(x?.rows)?x.rows:[];}catch{return [];}}
  function cacheTeams(rows){try{localStorage.setItem(TEAM_DIRECTORY_CACHE_KEY,JSON.stringify({savedAt:Date.now(),rows:Array.isArray(rows)?rows:[]}));}catch{}}
  function cachedTeamState(teamId){try{const x=JSON.parse(localStorage.getItem(TEAM_STATE_CACHE_PREFIX+teamId)||'null');return x&&x.state?x:null;}catch{return null;}}
  function cacheTeamState(teamId,row){if(!teamId||!row?.state)return;try{localStorage.setItem(TEAM_STATE_CACHE_PREFIX+teamId,JSON.stringify({state:row.state,revision:Number(row.revision??0),updated_at:row.updated_at||'',savedAt:Date.now()}));}catch{}}
  function authHeaders(accessToken){
    const h={'apikey':cfg.anonKey,'Content-Type':'application/json'};
    if(accessToken)h['Authorization']='Bearer '+accessToken;
    return h;
  }
  async function request(path,{method='GET',body=null,token=true,headers={}}={}){
    const res=await fetch(base()+path,{method,headers:{...authHeaders(token?session?.access_token:null),...headers},body:body==null?undefined:JSON.stringify(body)});
    const text=await res.text();
    let data=null;try{data=text?JSON.parse(text):null;}catch{data=text;}
    if(!res.ok){
      const msg=(data&&typeof data==='object'&&(data.msg||data.message||data.error_description||data.hint||data.details||data.error))||text||('HTTP '+res.status);
      const err=new Error(msg);err.status=res.status;err.data=data;throw err;
    }
    return {data,headers:res.headers,status:res.status};
  }
  async function refreshSession(){
    if(!session?.refresh_token)return false;
    try{
      const res=await fetch(base()+'/auth/v1/token?grant_type=refresh_token',{method:'POST',headers:authHeaders(),body:JSON.stringify({refresh_token:session.refresh_token})});
      const data=await res.json();
      if(!res.ok||!data.access_token)throw new Error(data?.msg||data?.error_description||'Session refresh failed');
      data.expires_at=Math.floor(Date.now()/1000)+(data.expires_in||3600);
      saveSession(data);return true;
    }catch{saveSession(null);return false;}
  }
  async function ensureFreshSession(){
    session=loadSession();
    if(!session?.access_token)return false;
    const exp=Number(session.expires_at||0);
    if(!exp||exp < Math.floor(Date.now()/1000)+90)return await refreshSession();
    return true;
  }
  async function signIn(email,password){
    const normalizedEmail=String(email||'').trim().toLowerCase();
    let res;
    try{
      res=await fetch(base()+'/auth/v1/token?grant_type=password',{method:'POST',headers:authHeaders(),body:JSON.stringify({email:normalizedEmail,password:String(password||'')})});
    }catch(e){
      throw new Error('Could not reach the sign-in service. Check your internet connection and try again.');
    }
    const text=await res.text();
    let data={};try{data=text?JSON.parse(text):{};}catch{data={message:text};}
    if(!res.ok){
      const raw=data?.error_description||data?.msg||data?.message||data?.error||'Sign in failed';
      if(/invalid login credentials/i.test(raw))throw new Error('Email or password not accepted. Use Forgot password if you are unsure of the password.');
      throw new Error(raw);
    }
    if(!data?.access_token||!data?.refresh_token)throw new Error('Sign in was accepted but no session was returned. Please try again.');
    data.expires_at=Math.floor(Date.now()/1000)+(data.expires_in||3600);
    saveSession(data);
    return data;
  }
  async function signUp(email,password,fullName,inviteCode){
    const url=base()+'/auth/v1/signup?redirect_to='+encodeURIComponent(AUTH_REDIRECT);
    const res=await fetch(url,{method:'POST',headers:authHeaders(),body:JSON.stringify({email,password,data:{full_name:fullName||''}})});
    const data=await res.json();
    if(!res.ok)throw new Error(data?.msg||data?.message||data?.error_description||'Account creation failed');
    if(inviteCode)localStorage.setItem(INVITE_KEY,inviteCode.trim());
    localStorage.setItem(VERIFY_EMAIL_KEY,email.trim());
    if(data?.access_token){data.expires_at=Math.floor(Date.now()/1000)+(data.expires_in||3600);saveSession(data);}
    return data;
  }
  async function resendSignup(email){
    const res=await fetch(base()+'/auth/v1/resend?redirect_to='+encodeURIComponent(AUTH_REDIRECT),{method:'POST',headers:authHeaders(),body:JSON.stringify({type:'signup',email})});
    const data=await res.json().catch(()=>({}));
    if(!res.ok)throw new Error(data?.msg||data?.message||data?.error_description||'Could not resend confirmation email');
    localStorage.setItem(VERIFY_EMAIL_KEY,email.trim());
    return data;
  }
  async function sendPasswordReset(email){
    const res=await fetch(base()+'/auth/v1/recover?redirect_to='+encodeURIComponent(AUTH_REDIRECT),{method:'POST',headers:authHeaders(),body:JSON.stringify({email})});
    const data=await res.json().catch(()=>({}));
    if(!res.ok)throw new Error(data?.msg||data?.message||data?.error_description||'Could not send password reset email');
    return data;
  }
  async function joinWithInvite(name,inviteCode){
    const res=await fetch(base()+'/functions/v1/join-team',{method:'POST',headers:{'apikey':cfg.anonKey,'Content-Type':'application/json'},body:JSON.stringify({name:String(name||'').trim(),invite_code:String(inviteCode||'').trim()})});
    const data=await res.json().catch(()=>({}));
    if(!res.ok||!data?.session?.access_token)throw new Error(data?.error||data?.message||'Could not join the team');
    const next=data.session;
    if(!next.expires_at)next.expires_at=Math.floor(Date.now()/1000)+Number(next.expires_in||3600);
    saveSession(next);
    return data;
  }

  async function loginWithPin(team,name,pin){
    const res=await fetch(base()+'/functions/v1/pin-login',{method:'POST',headers:{'apikey':cfg.anonKey,'Content-Type':'application/json'},body:JSON.stringify({team:String(team||'').trim(),name:String(name||'').trim(),pin:String(pin||'').trim()})});
    const data=await res.json().catch(()=>({}));
    if(!res.ok||!data?.session?.access_token)throw new Error(data?.error||data?.message||'Could not sign in with PIN');
    const next=data.session;if(!next.expires_at)next.expires_at=Math.floor(Date.now()/1000)+Number(next.expires_in||3600);saveSession(next);return data;
  }
  async function pinAdmin(action,payload={}){
    if(!session?.access_token)throw new Error('Sign in required');
    const res=await fetch(base()+'/functions/v1/pin-admin',{method:'POST',headers:{...authHeaders(session.access_token)},body:JSON.stringify({action,...payload})});
    const data=await res.json().catch(()=>({}));if(!res.ok)throw new Error(data?.error||data?.message||'PIN action failed');return data;
  }
  function accessPinPassword(pin){return `SHFC-PIN!${String(pin||'').trim()}#AFC`;}
  async function setAccessPin(pin){
    const clean=String(pin||'').trim();if(!/^\d{6}$/.test(clean))throw new Error('Choose a 6-digit PIN');
    if(['player','pending_parent'].includes(role())){
      await updatePassword(accessPinPassword(clean));
      await rpc(role()==='player'?'mark_my_player_pin_set':'mark_my_pending_parent_pin_set',{});
      context=await getContext();return {ok:true,pending_approval:role()==='pending_parent'};
    }
    const data=await pinAdmin('set_pin',{pin:clean});if(data?.session?.access_token){const next=data.session;if(!next.expires_at)next.expires_at=Math.floor(Date.now()/1000)+Number(next.expires_in||3600);saveSession(next);}context=await getContext();return data;
  }
  async function resetParentPin(userId){return await pinAdmin('reset_parent',{user_id:String(userId||'')});}
  function pendingParentPin(){const pin=localStorage.getItem(PENDING_PARENT_PIN_KEY)||'';return /^\d{6}$/.test(pin)?pin:'';}
  async function activatePendingParentPin(){
    const pin=pendingParentPin();
    if(!pin||context?.profile?.role!=='parent'||context?.profile?.pin_set_at)return false;
    await setAccessPin(pin);
    localStorage.removeItem(PENDING_PARENT_PIN_KEY);
    context=await getContext();
    return true;
  }

  async function updatePassword(newPassword){
    const {data}=await request('/auth/v1/user',{method:'PUT',body:{password:newPassword}});
    if(session&&data){session.user=data;saveSession(session);}
    return data;
  }
  async function hydrateSessionUser(){
    try{
      const {data}=await request('/auth/v1/user');
      if(session&&data){session.user=data;saveSession(session);}
    }catch{}
  }
  async function handleAuthCallback(uri,{duringBootstrap=false}={}){
    if(!uri)return null;
    try{
      const u=new URL(uri);
      const hash=new URLSearchParams((u.hash||'').replace(/^#/,''));
      const query=u.searchParams;
      const get=(k)=>hash.get(k)||query.get(k)||'';
      const error=get('error_description')||get('error');
      const errorCode=get('error_code');
      if(error){setGateHtml('signin',decodeURIComponent(error.replace(/\+/g,' '))+(errorCode?' ('+errorCode+')':''));return 'error';}
      const accessToken=get('access_token');
      const refreshToken=get('refresh_token');
      const type=get('type');
      if(!accessToken||!refreshToken){
        if(type==='recovery')setGateHtml('signin','The password reset link opened, but Supabase did not return a recovery session. Request a fresh reset email and try again.');
        return null;
      }
      const expiresIn=Number(get('expires_in')||3600);
      saveSession({access_token:accessToken,refresh_token:refreshToken,token_type:get('token_type')||'bearer',expires_in:expiresIn,expires_at:Math.floor(Date.now()/1000)+expiresIn});
      await hydrateSessionUser();
      localStorage.removeItem(VERIFY_EMAIL_KEY);
      if(type==='recovery'){
        setGateHtml('newpassword','Password reset verified. Choose your new password below.');
        return 'recovery';
      }
      if(!duringBootstrap) location.reload();
      return type||'auth';
    }catch(e){
      if(!duringBootstrap)setGateHtml('signin','The email link could not be opened in the app. '+(e.message||''));
      return 'error';
    }
  }
  async function rpc(name,args={}){
    const {data}=await request('/rest/v1/rpc/'+encodeURIComponent(name),{method:'POST',body:args});return data;
  }
  async function getContext(){
    let data=await rpc('get_my_context',{});
    if(Array.isArray(data)&&data.length===1)data=data[0];
    if(data&&data.context)data=data.context;
    return data;
  }
  async function claimInvite(code){return await rpc('claim_invite',{p_code:String(code||'').trim()});}
  async function listTeams(){
    if(testModeActive())return [TEST_TEAM];
    const {data}=await request('/rest/v1/teams?select=id,club_id,name,age_group,division,season,selkent_label,league_name,active&active=eq.true&order=age_group.asc,name.asc');
    const rows=Array.isArray(data)?data:[];if(rows.length)cacheTeams(rows);return rows;
  }
  function oldShapeTeam(t){
    if(!t)return null;
    const age = typeof t.age_group==='number'?'U'+t.age_group:String(t.age_group||'');
    return {id:t.id,selkentName:t.selkent_label||t.name,teamName:t.name,ageGroup:age,leagueName:t.league_name||t.name,division:t.division||'',season:t.season||''};
  }
  function role(){
    if(testModeActive())return 'coach';
    const r=context?.profile?.role||context?.role||'pending';
    return r==='club_admin'?'admin':r;
  }
  function assignedTeam(){
    if(testModeActive())return oldShapeTeam(TEST_TEAM);
    const t=context?.team||null;return oldShapeTeam(t);
  }
  function coachTeam(){
    if(testModeActive())return oldShapeTeam(TEST_TEAM);
    const direct=context?.coach_team||null;
    if(direct)return oldShapeTeam(direct);
    const id=context?.profile?.coach_team_id||null;
    if(!id)return null;
    return oldShapeTeam(visibleTeams.find(t=>t.id===id)||null);
  }
  function hasDualCoachAccess(){return role()==='admin'&&!!coachTeam();}
  function canEdit(){
    if(testModeActive())return true;
    const r=role();
    if(r==='coach'||r==='assistant_coach')return !!activeTeam&&context?.team?.id===activeTeam.id;
    if(r==='admin')return !!activeTeam&&!!context?.profile?.coach_team_id&&context.profile.coach_team_id===activeTeam.id;
    return false;
  }
  function canAdmin(){return !testModeActive()&&role()==='admin';}
  function teamMatchesState(team,state){
    const stateName=String(state?.division?.teamName||state?.meta?.teamName||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
    const teamName=String(team?.league_name||team?.name||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
    return stateName && teamName && (stateName===teamName || stateName.includes(teamName) || teamName.includes(stateName));
  }
  function chooseActiveTeam(localState){
    if(!visibleTeams.length)return null;
    const own=context?.team;
    if(own)return visibleTeams.find(t=>t.id===own.id)||own;
    const stored=localStorage.getItem(ACTIVE_TEAM_KEY);
    let found=visibleTeams.find(t=>t.id===stored);
    if(!found)found=visibleTeams.find(t=>teamMatchesState(t,localState));
    if(!found)found=visibleTeams[0];
    localStorage.setItem(ACTIVE_TEAM_KEY,found.id);return found;
  }
  async function fetchTeamState(teamId){
    const {data}=await request('/rest/v1/team_state?team_id=eq.'+encodeURIComponent(teamId)+'&select=state,revision,updated_at&limit=1');
    const row=Array.isArray(data)?data[0]:null;
    if(row){activeRevision=Number(row.revision||0);lastRemoteUpdatedAt=row.updated_at||'';cacheTeamState(teamId,row);}
    else{activeRevision=-1;lastRemoteUpdatedAt='';}
    return row||null;
  }
  async function getClubOverview(){
    if(!canAdmin())return [];
    const {data}=await request('/rest/v1/team_state?select=team_id,state,revision,updated_at&order=updated_at.desc');
    const rows=Array.isArray(data)?data:[];rows.forEach(row=>cacheTeamState(row.team_id,row));
    const byTeam=new Map(rows.map(row=>[row.team_id,row]));
    return visibleTeams.map(t=>{
      const row=byTeam.get(t.id)||{};
      return {team:oldShapeTeam(t),state:row.state||{},revision:Number(row.revision||0),updatedAt:row.updated_at||''};
    });
  }
  async function saveTeamStateNow(nextState,{force=false}={}){
    if(!configured()||!session||!activeTeam||!canEdit())return null;
    if(saving){pendingState=nextState;return null;}
    saving=true;emitStatus('Saving…','working');
    try{
      const data=await rpc('save_team_state',{p_team_id:activeTeam.id,p_state:nextState,p_expected_revision:force?-2:activeRevision});
      const row=Array.isArray(data)?data[0]:data;
      if(row){activeRevision=Number(row.revision);lastRemoteUpdatedAt=row.updated_at||lastRemoteUpdatedAt;cacheTeamState(activeTeam.id,{state:nextState,revision:activeRevision,updated_at:lastRemoteUpdatedAt});}
      emitStatus('Cloud synced','ok');return row;
    }catch(err){
      if(String(err.message||'').includes('STALE_STATE')){
        emitStatus('Newer cloud changes found — reloading','warn');
        const row=await fetchTeamState(activeTeam.id);
        if(row?.state&&hooks.onRemoteState)hooks.onRemoteState(row.state,{reason:'conflict'});
      }else emitStatus('Sync failed: '+(err.message||err),'error');
      throw err;
    }finally{
      saving=false;
      if(pendingState){const p=pendingState;pendingState=null;setTimeout(()=>saveTeamStateNow(p).catch(()=>{}),50);}
    }
  }
  function queueStateSave(nextState){
    if(!configured()||!canEdit()||!activeTeam)return;
    pendingState=JSON.parse(JSON.stringify(nextState));
    clearTimeout(saveTimer);
    saveTimer=setTimeout(()=>{const p=pendingState;pendingState=null;if(p)saveTeamStateNow(p).catch(()=>{});},700);
  }
  async function pullLatest({quiet=false}={}){
    if(!configured()||!session||!activeTeam)return null;
    if(!quiet)emitStatus('Checking cloud…','working');
    try{
      const before=activeRevision;
      const row=await fetchTeamState(activeTeam.id);
      if(row?.state&&Number(row.revision)!==before&&hooks.onRemoteState){hooks.onRemoteState(row.state,{reason:'pull'});}
      if(!quiet)emitStatus('Cloud synced','ok');
      return row;
    }catch(err){if(!quiet)emitStatus('Sync failed: '+(err.message||err),'error');return null;}
  }
  async function switchAdminTeam(teamId,seedFactory){
    if(!canAdmin())throw new Error('Club Admin access required');
    const team=visibleTeams.find(t=>t.id===teamId);if(!team)throw new Error('Team not found');
    if(pendingState&&canEdit()){const p=pendingState;pendingState=null;await saveTeamStateNow(p).catch(()=>{});}
    activeTeam=team;localStorage.setItem(ACTIVE_TEAM_KEY,team.id);
    const cached=cachedTeamState(team.id);
    if(cached?.state){
      activeRevision=Number(cached.revision??0);lastRemoteUpdatedAt=cached.updated_at||'';
      hooks.onRemoteState&&hooks.onRemoteState(cached.state,{reason:'switch-cache'});
      updateCloudPanel();
      fetchTeamState(team.id).then(row=>{if(row?.state&&Number(row.revision)!==Number(cached.revision))hooks.onRemoteState&&hooks.onRemoteState(row.state,{reason:'switch-refresh'});}).catch(()=>{});
      return oldShapeTeam(team);
    }
    const row=await fetchTeamState(team.id);
    if(row?.state){hooks.onRemoteState&&hooks.onRemoteState(row.state,{reason:'switch'});}
    else if(seedFactory){
      const seed=seedFactory(oldShapeTeam(team));
      activeRevision=-1;
      if(canEdit())await saveTeamStateNow(seed);
      hooks.onRemoteState&&hooks.onRemoteState(seed,{reason:canEdit()?'switch-seed':'switch-preview'});
    }
    updateCloudPanel();return oldShapeTeam(team);
  }
  async function createInvite({teamId,role:inviteRole,label='',expiresHours=168}){
    if(!['admin','coach','assistant_coach'].includes(role()))throw new Error('Coaching staff or Club Admin access required');
    if(['coach','assistant_coach'].includes(role())&&!['parent','player'].includes(inviteRole))throw new Error('Coaching staff can only invite parents or players');
    if(inviteRole==='club_admin'&&role()!=='admin')throw new Error('Only a Club Admin can invite another Club Admin');
    if(inviteRole!=='club_admin'&&!teamId)throw new Error('Choose a team');
    if(inviteRole==='player'){const target=visibleTeams.find(t=>String(t.id)===String(teamId));const age=Number(target?.age_group||String(target?.ageGroup||'').replace(/\D/g,''));if(age!==15)throw new Error('Player app access is only available to U15 squads');}
    const data=await rpc('create_invite',{p_team_id:teamId||null,p_role:inviteRole,p_label:label||'',p_expires_hours:expiresHours});
    return Array.isArray(data)?data[0]:data;
  }
  async function listClubCoaches(){
    if(role()!=='admin')return [];
    const data=await rpc('list_club_coaches',{});
    return Array.isArray(data)?data:[];
  }
  async function listClubAccessAccounts(){
    if(role()!=='admin')return [];
    const data=await rpc('list_club_access_accounts',{});
    return Array.isArray(data)?data:[];
  }
  async function removeClubCoach(userId){
    if(role()!=='admin')throw new Error('Club Admin access required');
    return await rpc('remove_club_coach',{p_user_id:userId});
  }
  async function listPublishedClubResults(){
    if(!['admin','coach','assistant_coach'].includes(role()))return [];
    const data=await rpc('list_published_club_results',{});
    return Array.isArray(data)?data:[];
  }
  async function listTeamMembers(teamId=null){
    if(testModeActive())return [];
    if(!['admin','coach','assistant_coach'].includes(role()))return [];
    const data=await rpc('list_team_members_v2',{p_team_id:teamId||null});
    return Array.isArray(data)?data:[];
  }
  async function listMessageContacts(){
    if(!['admin','coach','assistant_coach','parent'].includes(role()))return [];
    const data=await rpc('list_message_contacts',{});
    return Array.isArray(data)?data:[];
  }
  async function listClubMessages(){
    if(!['admin','coach','assistant_coach','parent'].includes(role()))return [];
    const {data}=await request('/rest/v1/club_messages?select=id,thread_id,club_id,sender_user_id,recipient_user_id,subject,body,created_at,read_at&order=created_at.asc');
    return Array.isArray(data)?data:[];
  }
  async function sendClubMessage({recipientUserId,subject='',body='',threadId=null}={}){
    if(!['admin','coach','assistant_coach','parent'].includes(role()))throw new Error('Inbox access required');
    const recipient=String(recipientUserId||'').trim();
    const text=String(body||'').trim();
    if(!recipient)throw new Error('Choose a recipient');
    if(!text)throw new Error('Write a message first');
    if(text.length>4000)throw new Error('Message is too long');
    const clubId=context?.profile?.club_id||context?.club?.id||null;
    const sender=session?.user?.id||null;
    if(!clubId||!sender)throw new Error('Your club session is not ready');
    const payload={thread_id:threadId||crypto.randomUUID(),club_id:clubId,sender_user_id:sender,recipient_user_id:recipient,subject:String(subject||'').trim().slice(0,120),body:text};
    const {data}=await request('/rest/v1/club_messages',{method:'POST',body:payload,headers:{Prefer:'return=representation'}});
    return Array.isArray(data)?data[0]:data;
  }
  async function markClubMessagesRead(ids=[]){
    if(!['admin','coach','assistant_coach','parent'].includes(role()))return false;
    const clean=[...new Set((ids||[]).map(String).filter(x=>/^[0-9a-f-]{36}$/i.test(x)))];
    if(!clean.length)return true;
    await request('/rest/v1/club_messages?id=in.('+clean.join(',')+')',{method:'PATCH',body:{read_at:new Date().toISOString()},headers:{Prefer:'return=minimal'}});
    return true;
  }

  async function listParentPlayerLinks(parentUserId=null){
    if(testModeActive())return [];
    if(!activeTeam||!['admin','coach','assistant_coach','parent'].includes(role()))return [];
    let q=`/rest/v1/parent_player_links?select=id,club_id,team_id,parent_user_id,player_name,shirt_number,created_at&team_id=eq.${encodeURIComponent(activeTeam.id)}&order=shirt_number.asc,player_name.asc`;
    if(parentUserId)q+=`&parent_user_id=eq.${encodeURIComponent(String(parentUserId))}`;
    const {data}=await request(q);return Array.isArray(data)?data:[];
  }
  async function saveParentPlayerLinks(parentUserId,players=[]){
    if(testModeActive())return players||[];
    if(!activeTeam||!['admin','coach','assistant_coach'].includes(role()))throw new Error('Coaching staff or Club Admin access required');
    const parent=String(parentUserId||'').trim();if(!parent)throw new Error('Choose a parent');
    await request(`/rest/v1/parent_player_links?team_id=eq.${encodeURIComponent(activeTeam.id)}&parent_user_id=eq.${encodeURIComponent(parent)}`,{method:'DELETE',headers:{Prefer:'return=minimal'}});
    const clubId=context?.profile?.club_id||context?.club?.id||null;
    const sender=session?.user?.id||null;
    const rows=(players||[]).filter(x=>x&&x.name).map(x=>({club_id:clubId,team_id:activeTeam.id,parent_user_id:parent,player_name:String(x.name).trim().slice(0,80),shirt_number:Number(x.number)||null,created_by:sender}));
    if(rows.length)await request('/rest/v1/parent_player_links',{method:'POST',body:rows,headers:{Prefer:'return=representation'}});
    return rows;
  }
  async function listPlayerAccountLinks(userId=null){
    if(testModeActive())return [];
    if(!activeTeam||!['admin','coach','assistant_coach','player'].includes(role()))return [];
    let q=`/rest/v1/player_account_links?select=id,club_id,team_id,user_id,player_name,created_at&team_id=eq.${encodeURIComponent(activeTeam.id)}&order=player_name.asc`;
    if(userId)q+=`&user_id=eq.${encodeURIComponent(String(userId))}`;
    const {data}=await request(q);return Array.isArray(data)?data:[];
  }
  async function listMatchAvailability(fixtureKey){
    if(testModeActive())return [];
    if(!activeTeam||!fixtureKey)return [];
    const q=`/rest/v1/match_availability?select=id,team_id,fixture_key,parent_user_id,player_name,status,updated_at&team_id=eq.${encodeURIComponent(activeTeam.id)}&fixture_key=eq.${encodeURIComponent(fixtureKey)}&order=updated_at.desc`;
    const {data}=await request(q);return Array.isArray(data)?data:[];
  }
  async function saveMatchAvailability({fixtureKey,playerName,status}={}){
    const r=role();if(!['parent','player'].includes(r))throw new Error('Parent or player access required');
    if(!activeTeam||!session?.user?.id)throw new Error('Team session is not ready');
    if(!fixtureKey||!['available','unavailable','unsure'].includes(status))throw new Error('Choose your availability');
    const name=String(playerName||'').trim().slice(0,80);if(!name)throw new Error('No linked player was selected');
    const links=r==='player'?await listPlayerAccountLinks(session.user.id):await listParentPlayerLinks(session.user.id);
    if(!links.some(x=>x.player_name===name))throw new Error('This player profile is not linked to this account');
    const payload={team_id:activeTeam.id,fixture_key:String(fixtureKey),parent_user_id:session.user.id,player_name:name,status,updated_at:new Date().toISOString()};
    const {data}=await request('/rest/v1/match_availability?on_conflict=team_id,fixture_key,player_name',{method:'POST',body:payload,headers:{Prefer:'resolution=merge-duplicates,return=representation'}});
    return Array.isArray(data)?data[0]:data;
  }
  async function listSelkentTeamDirectory(ageGroup){
    const age=Number(ageGroup||0);
    if(testModeActive()){return age===9?[
      {id:'test-1',club_name:'Boca',team_label:'Under 9 Polars',display_name:'Boca Polars',age_group:9,age_variant:'U9'},
      {id:'test-2',club_name:'Cray Wanderers',team_label:'Under 9 Blue',display_name:'Cray Wanderers Blue',age_group:9,age_variant:'U9'},
      {id:'test-3',club_name:'Hoo FC',team_label:'Under 9',display_name:'Hoo FC',age_group:9,age_variant:'U9'}
    ]:[];}
    if(!session?.access_token)return [];
    if(!age)return [];
    const q=`/rest/v1/selkent_team_directory?select=id,source_club_id,club_name,team_label,display_name,age_group,age_variant,club_url,last_seen_at&age_group=eq.${age}&order=display_name.asc`;
    const {data}=await request(q);return Array.isArray(data)?data:[];
  }
  async function syncSelkentTeamDirectory(){
    if(!session?.access_token)throw new Error('Sign in required');
    const res=await fetch(base()+'/functions/v1/selkent-teams-sync',{method:'POST',headers:{...authHeaders(session.access_token)},body:'{}'});
    const data=await res.json().catch(()=>({}));if(!res.ok)throw new Error(data?.error||data?.message||'Could not refresh Selkent team directory');return data;
  }

  async function getCoachMatchNote(matchId){
    if(testModeActive())return null;
    if(!activeTeam||!matchId||!['admin','coach','assistant_coach'].includes(role()))return null;
    const {data}=await request(`/rest/v1/coach_match_notes?select=id,team_id,match_id,note,updated_at,updated_by&team_id=eq.${encodeURIComponent(activeTeam.id)}&match_id=eq.${encodeURIComponent(String(matchId))}&limit=1`);
    return Array.isArray(data)?(data[0]||null):null;
  }
  async function saveCoachMatchNote(matchId,note){
    if(testModeActive())return {match_id:String(matchId||''),note:String(note||'')};
    if(!activeTeam||!matchId||!canEdit())throw new Error('Coach access required');
    const payload={team_id:activeTeam.id,match_id:String(matchId),note:String(note||'').slice(0,4000),updated_by:session?.user?.id,updated_at:new Date().toISOString()};
    const {data}=await request('/rest/v1/coach_match_notes?on_conflict=team_id,match_id',{method:'POST',body:payload,headers:{Prefer:'resolution=merge-duplicates,return=representation'}});
    return Array.isArray(data)?data[0]:data;
  }
  async function listAnnouncements(){if(testModeActive())return [];const data=await rpc('list_announcements_for_me',{});return Array.isArray(data)?data:(Array.isArray(data?.data)?data.data:[]);}
  async function createAnnouncement({title,body,audience='whole_club',ageGroup=null,teamId=null,pinned=false,important=false,expiresAt=null}={}){return await rpc('create_club_announcement',{p_title:String(title||'').trim(),p_body:String(body||'').trim(),p_audience:audience,p_age_group:ageGroup==null?null:Number(ageGroup),p_team_id:teamId||null,p_pinned:!!pinned,p_important:!!important,p_expires_at:expiresAt||null});}
  async function markAnnouncementRead(id){return await rpc('mark_announcement_read',{p_announcement_id:id});}
  async function deleteAnnouncement(id){return await rpc('delete_club_announcement',{p_announcement_id:id});}
  async function listMatchAttendance(matchId){if(testModeActive())return [];if(!activeTeam||!matchId||!['admin','coach','assistant_coach'].includes(role()))return [];const {data}=await request(`/rest/v1/match_attendance?select=id,team_id,match_id,player_name,status,updated_at,updated_by&team_id=eq.${encodeURIComponent(activeTeam.id)}&match_id=eq.${encodeURIComponent(String(matchId))}&order=player_name.asc`);return Array.isArray(data)?data:[];}
  async function saveMatchAttendance(matchId,rows=[]){if(testModeActive())return rows||[];if(!activeTeam||!matchId||!canEdit())throw new Error('Coach access required');const payload=(rows||[]).filter(r=>r?.player_name&&r?.status).map(r=>({player_name:String(r.player_name),status:String(r.status)}));await rpc('save_match_attendance',{p_team_id:activeTeam.id,p_match_id:String(matchId),p_rows:payload});return payload;}

  async function getAvailabilitySettings(fixtureKey){
    if(testModeActive()||!activeTeam||!fixtureKey)return null;
    const {data}=await request(`/rest/v1/fixture_availability_settings?select=team_id,fixture_key,deadline,updated_at&team_id=eq.${encodeURIComponent(activeTeam.id)}&fixture_key=eq.${encodeURIComponent(String(fixtureKey))}&limit=1`);
    return Array.isArray(data)?(data[0]||null):null;
  }
  async function setAvailabilityDeadline(fixtureKey,deadline){
    if(testModeActive())return true;if(!activeTeam||!canEdit())throw new Error('Coach access required');
    return await rpc('set_availability_deadline',{p_team_id:activeTeam.id,p_fixture_key:String(fixtureKey),p_deadline:deadline||null});
  }
  async function sendAvailabilityReminder(fixtureKey){
    if(testModeActive())return 0;if(!activeTeam||!canEdit())throw new Error('Coach access required');
    return Number(await rpc('send_availability_reminder',{p_team_id:activeTeam.id,p_fixture_key:String(fixtureKey)})||0);
  }
  async function listNotifications(){if(testModeActive())return [];const data=await rpc('list_notifications_for_me',{});return Array.isArray(data)?data:(Array.isArray(data?.data)?data.data:[]);}
  async function markNotificationRead(id){if(testModeActive())return true;return await rpc('mark_notification_read',{p_notification_id:id});}
  async function notifyFixtureChange(fixtureKey,body){if(testModeActive())return 0;if(!activeTeam||!canEdit())return 0;return Number(await rpc('notify_fixture_change',{p_team_id:activeTeam.id,p_fixture_key:String(fixtureKey),p_body:String(body||'')})||0);}
  async function notifySelectedSquad(fixtureKey,playerNames=[]){if(testModeActive())return 0;if(!activeTeam||!canEdit())throw new Error('Coach access required');return Number(await rpc('notify_selected_squad',{p_team_id:activeTeam.id,p_fixture_key:String(fixtureKey),p_player_names:playerNames})||0);}
  async function notifyMatchReport(matchId,opponent,score){if(testModeActive())return 0;if(!activeTeam||!canEdit())return 0;return Number(await rpc('notify_match_report',{p_team_id:activeTeam.id,p_match_id:String(matchId||''),p_opponent:String(opponent||''),p_score:String(score||'')})||0);}
  async function listPlayerAppearanceStats(){if(testModeActive())return [];if(!activeTeam)return [];const data=await rpc('list_player_appearance_stats',{p_team_id:activeTeam.id});return Array.isArray(data)?data:[];}

  async function approveParent(userId){
    if(!['admin','coach','assistant_coach'].includes(role()))throw new Error('Coaching staff or Club Admin access required');
    return await rpc('approve_parent',{p_user_id:userId});
  }
  async function removeTeamMember(userId){
    if(!['admin','coach','assistant_coach'].includes(role()))throw new Error('Coaching staff or Club Admin access required');
    return await rpc('remove_team_member',{p_user_id:userId});
  }
  async function syncTeamDirectory(teams){
    if(!canAdmin())return 0;
    const payload=(teams||[]).map(t=>({name:t.teamName,age_group:Number(String(t.ageGroup||'').replace(/\D/g,''))||0,selkent_label:t.selkentName,league_name:t.leagueName})).filter(t=>t.name&&t.age_group&&t.selkent_label&&t.league_name);
    if(!payload.length)return 0;
    const result=await rpc('sync_team_directory',{p_teams:payload});
    visibleTeams=await listTeams();
    return Number(result?.count??result??payload.length);
  }
  function visibleTeamList(){return visibleTeams.map(oldShapeTeam);}
  function currentTeam(){return oldShapeTeam(activeTeam);}
  function inviteAccessActive(){
    return Boolean(context?.profile?.access_method==='invite' || session?.user?.user_metadata?.invite_access || /@access\.shootershill\.app$/i.test(String(session?.user?.email||'')));
  }
  function inviteAccessLocked(){
    return localStorage.getItem(INVITE_LOCK_KEY)==='1';
  }
  function setInviteAccessLocked(locked){
    if(locked) localStorage.setItem(INVITE_LOCK_KEY,'1');
    else localStorage.removeItem(INVITE_LOCK_KEY);
  }
  function clearInviteAccess(){
    setInviteAccessLocked(false);
    saveSession(null);context=null;visibleTeams=[];activeTeam=null;localStorage.removeItem(INVITE_KEY);localStorage.removeItem(PENDING_PARENT_PIN_KEY);
  }

  function setGateHtml(mode='join',message='',prefillEmail=''){
    const gate=document.getElementById('activation-gate');
    if(!gate)return;
    gate.classList.remove('hidden');
    document.body.classList.add('auth-open');
    document.querySelector('.app-shell')?.classList.add('account-locked');

    if(mode==='preapproval-pin'){
      gate.innerHTML=`<div class="activation-card cloud-auth-card"><img src="club-logo.png" alt="Shooters Hill AFC logo" class="activation-logo"/><p class="kicker">Parent access</p><h1>Create your 6-digit PIN</h1><p class="muted">Choose your returning-access PIN now. It will become active automatically once your coach approves your parent access.</p><label for="cloud-pin-preapproval">6-digit PIN<input id="cloud-pin-preapproval" type="password" inputmode="numeric" maxlength="6" autocomplete="new-password" placeholder="••••••"/></label><label for="cloud-pin-preapproval2">Confirm PIN<input id="cloud-pin-preapproval2" type="password" inputmode="numeric" maxlength="6" autocomplete="new-password" placeholder="••••••"/></label><p class="auth-notice ${message?'':'hidden'}" id="cloud-auth-notice">${escapeHtml(message)}</p><p class="activation-error hidden" id="cloud-auth-error"></p><button class="primary-button large" id="cloud-pin-preapproval-save">Save PIN & wait for approval</button></div>`;
      document.getElementById('cloud-pin-preapproval-save')?.addEventListener('click',async()=>{const a=document.getElementById('cloud-pin-preapproval')?.value||'';const b=document.getElementById('cloud-pin-preapproval2')?.value||'';if(!/^\d{6}$/.test(a))return authError('Choose exactly 6 digits.');if(a!==b)return authError('The PINs do not match.');try{await setAccessPin(a);localStorage.removeItem(PENDING_PARENT_PIN_KEY);setGateHtml('approval','PIN saved. It will work automatically once your coach approves your access.');}catch(e){authError(e.message||String(e));}});return;
    }
    if(mode==='pinsetup'){
      const forced=Boolean(context?.profile?.pin_reset_required),player=context?.profile?.role==='player';
      gate.innerHTML=`<div class="activation-card cloud-auth-card"><img src="club-logo.png" alt="Shooters Hill AFC logo" class="activation-logo"/><p class="kicker">${player?'Player':'Parent'} access</p><h1>${forced?'Choose a new PIN':'Create your access PIN'}</h1><p class="muted">Use a 6-digit PIN for future access on this or another device. Keep it private.</p><label for="cloud-pin-new">6-digit PIN<input id="cloud-pin-new" type="password" inputmode="numeric" maxlength="6" autocomplete="new-password" placeholder="••••••"/></label><label for="cloud-pin-new2">Confirm PIN<input id="cloud-pin-new2" type="password" inputmode="numeric" maxlength="6" autocomplete="new-password" placeholder="••••••"/></label><p class="auth-notice ${message?'':'hidden'}" id="cloud-auth-notice">${escapeHtml(message)}</p><p class="activation-error hidden" id="cloud-auth-error"></p><button class="primary-button large" id="cloud-pin-save">Save PIN</button></div>`;
      document.getElementById('cloud-pin-save')?.addEventListener('click',async()=>{const a=document.getElementById('cloud-pin-new')?.value||'';const b=document.getElementById('cloud-pin-new2')?.value||'';if(!/^\d{6}$/.test(a))return authError('Choose exactly 6 digits.');if(a!==b)return authError('The PINs do not match.');try{await setAccessPin(a);hideGate();location.reload();}catch(e){authError(e.message||String(e));}});return;
    }
    if(mode==='pinlogin'){
      const teamOptions=PIN_TEAM_OPTIONS.map(t=>`<option value="${escapeHtml(t)}">${escapeHtml(t)}</option>`).join('');
      gate.innerHTML=`<div class="activation-card cloud-auth-card"><img src="club-logo.png" alt="Shooters Hill AFC logo" class="activation-logo"/><p class="kicker">Returning access</p><h1>Sign in with PIN</h1><p class="muted">Choose your team, then enter your name and 6-digit PIN.</p><label for="cloud-pin-team">Team<select id="cloud-pin-team"><option value="">Choose team…</option>${teamOptions}</select></label><label for="cloud-pin-name">Name<input id="cloud-pin-name" type="text" autocapitalize="words" spellcheck="false" placeholder="Your name"/></label><label for="cloud-pin-login">6-digit PIN<input id="cloud-pin-login" type="password" inputmode="numeric" maxlength="6" autocomplete="current-password" placeholder="••••••"/></label><p class="auth-notice ${message?'':'hidden'}" id="cloud-auth-notice">${escapeHtml(message)}</p><p class="activation-error hidden" id="cloud-auth-error"></p><button class="primary-button large" id="cloud-pin-login-submit">Continue</button><button class="text-button" id="cloud-pin-back">Use an invite code instead</button></div>`;
      document.getElementById('cloud-pin-back')?.addEventListener('click',()=>setGateHtml('join'));
      document.getElementById('cloud-pin-login-submit')?.addEventListener('click',async()=>{const team=document.getElementById('cloud-pin-team')?.value?.trim()||'';const name=document.getElementById('cloud-pin-name')?.value?.trim()||'';const pin=document.getElementById('cloud-pin-login')?.value||'';if(team.length<2||name.length<2||!/^\d{6}$/.test(pin))return authError('Enter your team, name and 6-digit PIN.');try{localStorage.removeItem(TEST_MODE_KEY);setInviteAccessLocked(false);await loginWithPin(team,name,pin);context=await getContext();if(context?.profile?.pin_reset_required){setGateHtml('pinsetup','Your temporary PIN worked. Choose a new PIN now.');return;}hideGate();window.dispatchEvent(new CustomEvent('valiants-authenticated',{detail:{source:'pin'}}));}catch(e){authError(e.message||String(e));}});return;
    }

    if(mode==='approval'||context?.profile?.role==='pending_parent'){
      gate.innerHTML=`<div class="activation-card cloud-auth-card"><img src="club-logo.png" alt="Shooters Hill Football Club logo" class="activation-logo"/><p class="kicker">Parent access</p><h1>Waiting for approval</h1><p class="muted">Your request is waiting for coach approval. Team data will appear here once a team coach approves the request.</p><p class="auth-notice ${message?'':'hidden'}" id="cloud-auth-notice">${escapeHtml(message)}</p><button class="primary-button large" id="cloud-check-approval">Check approval</button><button class="text-button" id="cloud-reset-device">Use a different invite</button></div>`;
      document.getElementById('cloud-check-approval')?.addEventListener('click',async()=>{try{context=await getContext();if(context?.profile?.role==='parent'){try{await activatePendingParentPin();}catch(e){return setGateHtml('pinsetup','Access approved. Please confirm your 6-digit PIN.');}location.reload();}else showNotice('Still waiting for a coach to approve access.');}catch(e){authError(e.message||String(e));}});
      document.getElementById('cloud-reset-device')?.addEventListener('click',()=>{clearInviteAccess();location.reload();});
      setTimeout(async()=>{try{context=await getContext();if(context?.profile?.role==='parent'){try{await activatePendingParentPin();}catch{}location.reload();}}catch{}},15000);
      return;
    }

    if(mode==='resume'){
      const profile=context?.profile||{};
      const label=profile.role==='parent'||profile.role==='pending_parent'?'Parent access':'Team access';
      gate.innerHTML=`<div class="activation-card cloud-auth-card"><img src="club-logo.png" alt="Shooters Hill Football Club logo" class="activation-logo"/><p class="kicker">${label}</p><h1>Signed out on this device</h1><p class="muted">Tap below to continue with your saved access on this phone, or choose a different invite if this device is changing hands.</p><p class="auth-notice ${message?'':'hidden'}" id="cloud-auth-notice">${escapeHtml(message)}</p><button class="primary-button large" id="cloud-resume-access">Continue to app</button><button class="text-button" id="cloud-reset-device">Use a different invite</button></div>`;
      document.getElementById('cloud-resume-access')?.addEventListener('click',()=>{setInviteAccessLocked(false);location.reload();});
      document.getElementById('cloud-reset-device')?.addEventListener('click',()=>{clearInviteAccess();location.reload();});
      return;
    }

    if(mode==='revoked'||context?.profile?.role==='revoked'){
      gate.innerHTML=`<div class="activation-card cloud-auth-card"><img src="club-logo.png" alt="Shooters Hill Football Club logo" class="activation-logo"/><p class="kicker">Team access</p><h1>Access removed</h1><p class="muted">This device no longer has access to a team. Ask a coach or Club Admin for a new invite code.</p><button class="primary-button large" id="cloud-reset-device">Join with a new invite</button></div>`;
      document.getElementById('cloud-reset-device')?.addEventListener('click',e=>signOut(e));return;
    }

    if(mode==='verify'){
      const email=prefillEmail||localStorage.getItem(VERIFY_EMAIL_KEY)||'';
      gate.innerHTML=`<div class="activation-card cloud-auth-card"><img src="club-logo.png" alt="Shooters Hill Football Club logo" class="activation-logo"/><p class="kicker">Verify Club Admin email</p><h1>Check your inbox</h1><p class="muted">Tap the confirmation link in the email. It will return you to the app.</p><label for="cloud-verify-email">Email address<input id="cloud-verify-email" type="email" autocomplete="off" value="${escapeHtml(email)}" placeholder="name@example.com"/></label><p class="auth-notice ${message?'':'hidden'}" id="cloud-auth-notice">${escapeHtml(message)}</p><p class="activation-error hidden" id="cloud-auth-error"></p><button class="primary-button large" id="cloud-resend-btn">Resend confirmation email</button><button class="text-button" id="cloud-back-signin">Back to Club Admin sign in</button></div>`;
      document.getElementById('cloud-resend-btn')?.addEventListener('click',async()=>{const addr=document.getElementById('cloud-verify-email')?.value?.trim();if(!addr)return authError('Enter your email address.');try{await resendSignup(addr);showNotice('Confirmation email sent.');}catch(e){authError(e.message||String(e));}});
      document.getElementById('cloud-back-signin')?.addEventListener('click',()=>setGateHtml('signin'));return;
    }

    if(mode==='forgot'){
      gate.innerHTML=`<div class="activation-card cloud-auth-card"><img src="club-logo.png" alt="Shooters Hill Football Club logo" class="activation-logo"/><p class="kicker">Club Admin recovery</p><h1>Reset password</h1><p class="muted">Password recovery is only needed for Club Admin accounts. Returning parents use their 6-digit PIN; coaches can reset a forgotten parent PIN.</p><label for="cloud-reset-email">Email address<input id="cloud-reset-email" type="email" autocomplete="off" autocapitalize="none" spellcheck="false" placeholder="name@example.com"/></label><p class="auth-notice ${message?'':'hidden'}" id="cloud-auth-notice">${escapeHtml(message)}</p><p class="activation-error hidden" id="cloud-auth-error"></p><button class="primary-button large" id="cloud-reset-send">Send reset email</button><button class="text-button" id="cloud-back-signin">Back</button></div>`;
      document.getElementById('cloud-reset-send')?.addEventListener('click',async()=>{const email=document.getElementById('cloud-reset-email')?.value?.trim();if(!email)return authError('Enter your email address.');try{await sendPasswordReset(email);showNotice('Password reset email sent. Open the link in that email on this Android device to return to the app and choose a new password.');}catch(e){authError(e.message||String(e));}});
      document.getElementById('cloud-back-signin')?.addEventListener('click',()=>setGateHtml('signin'));return;
    }

    if(mode==='newpassword'){
      gate.innerHTML=`<div class="activation-card cloud-auth-card"><img src="club-logo.png" alt="Shooters Hill Football Club logo" class="activation-logo"/><p class="kicker">Club Admin account</p><h1>Choose new password</h1><label for="cloud-new-password">New password<input id="cloud-new-password" type="password" autocomplete="new-password" placeholder="New password"/></label><label for="cloud-new-password2">Confirm new password<input id="cloud-new-password2" type="password" autocomplete="new-password" placeholder="Repeat new password"/></label><p class="auth-notice ${message?'':'hidden'}" id="cloud-auth-notice">${escapeHtml(message)}</p><p class="activation-error hidden" id="cloud-auth-error"></p><button class="primary-button large" id="cloud-password-save">Save new password</button><button class="text-button" id="cloud-password-cancel">Cancel</button></div>`;
      document.getElementById('cloud-password-save')?.addEventListener('click',async()=>{const a=document.getElementById('cloud-new-password')?.value||'';const b=document.getElementById('cloud-new-password2')?.value||'';if(a.length<8)return authError('Use at least 8 characters.');if(a!==b)return authError('The passwords do not match.');try{await updatePassword(a);location.reload();}catch(e){authError(e.message||String(e));}});
      document.getElementById('cloud-password-cancel')?.addEventListener('click',()=>{if(session?.access_token)location.reload();else setGateHtml('signin');});return;
    }

    if(mode==='signin'){
      gate.innerHTML=`<div class="activation-card cloud-auth-card"><img src="club-logo.png" alt="Shooters Hill Football Club logo" class="activation-logo"/><p class="kicker">Club administration</p><h1>Club Admin sign in</h1><p class="muted">Coaches and Assistant Coaches use team access. Returning parents can sign in with their 6-digit PIN.</p><label for="cloud-email">Email address<input id="cloud-email" type="email" autocomplete="username" autocapitalize="none" spellcheck="false" placeholder="name@example.com"/></label><label for="cloud-password">Password<input id="cloud-password" type="password" autocomplete="current-password" placeholder="Password"/></label><p class="auth-notice ${message?'':'hidden'}" id="cloud-auth-notice">${escapeHtml(message)}</p><p class="activation-error hidden" id="cloud-auth-error"></p><button class="primary-button large" id="cloud-auth-submit">Sign in</button><button class="text-button cloud-forgot-password" id="cloud-forgot-password">Forgot password?</button><button class="text-button" id="cloud-back-join">Join a team with invite code</button></div>`;
      document.getElementById('cloud-forgot-password')?.addEventListener('click',()=>setGateHtml('forgot'));
      document.getElementById('cloud-back-join')?.addEventListener('click',()=>setGateHtml('join'));
      document.getElementById('cloud-auth-submit')?.addEventListener('click',async()=>{
        const email=document.getElementById('cloud-email')?.value?.trim();
        const password=document.getElementById('cloud-password')?.value||'';
        if(!email||!password)return authError('Enter your email and password.');
        const btn=document.getElementById('cloud-auth-submit');
        if(btn){btn.disabled=true;btn.textContent='Signing in…';}
        try{
          localStorage.removeItem(TEST_MODE_KEY);setInviteAccessLocked(false);
          await signIn(email,password);
          await hydrateSessionUser();
          let signedContext=null;
          try{signedContext=await getContext();}catch(e){throw new Error('Sign in succeeded, but the club profile could not be loaded. Check your connection and try again.');}
          if(!signedContext?.profile){throw new Error('Sign in succeeded, but no club access profile is attached to this account.');}
          context=signedContext;
          hideGate();
          window.dispatchEvent(new CustomEvent('valiants-authenticated',{detail:{source:'signin'}}));
        }catch(e){
          const msg=e.message||String(e);
          if(/confirm|verified/i.test(msg)){
            localStorage.setItem(VERIFY_EMAIL_KEY,email);
            setGateHtml('verify','Your email still needs confirming.',email);
          }else authError(msg);
          if(btn){btn.disabled=false;btn.textContent='Sign in';}
        }
      });
      return;
    }

    gate.innerHTML=`<div class="activation-card cloud-auth-card"><img src="club-logo.png" alt="Shooters Hill Football Club logo" class="activation-logo"/><p class="kicker">Shooters Hill app access</p><h1>Join the app</h1><p class="muted">Enter your name and the invite code supplied by your coaching staff or Club Admin. The code determines your access level and team automatically.</p><label for="cloud-join-name">Your name<input id="cloud-join-name" type="text" autocomplete="off" autocapitalize="words" spellcheck="false" placeholder="type name here"/></label><label for="cloud-join-code">Invite code<input id="cloud-join-code" type="text" autocomplete="one-time-code" autocapitalize="characters" spellcheck="false" placeholder="SH-…"/></label><p class="auth-notice ${message?'':'hidden'}" id="cloud-auth-notice">${escapeHtml(message)}</p><p class="activation-error hidden" id="cloud-auth-error"></p><button class="primary-button large" id="cloud-join-submit">Continue</button><button class="text-button" id="cloud-returning-parent">Returning parent / player · use PIN</button><button class="text-button" id="cloud-admin-signin">Club Admin sign in</button>${debugBuild()?'<button class="secondary-button large quick-test-login" id="cloud-quick-test">Quick test login · Coach</button><p class="quick-test-note">Debug APK only · local data · cloud writes disabled</p>':''}</div>`;
    requestAnimationFrame(()=>['cloud-join-name','cloud-join-code'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';}));
    document.getElementById('cloud-returning-parent')?.addEventListener('click',()=>setGateHtml('pinlogin'));
    document.getElementById('cloud-admin-signin')?.addEventListener('click',()=>setGateHtml('signin'));
    document.getElementById('cloud-quick-test')?.addEventListener('click',()=>{localStorage.setItem(TEST_MODE_KEY,'coach');hideGate();window.dispatchEvent(new CustomEvent('valiants-authenticated',{detail:{source:'quick-test'}}));});
    document.getElementById('cloud-join-submit')?.addEventListener('click',async()=>{const name=document.getElementById('cloud-join-name')?.value?.trim()||'';const code=document.getElementById('cloud-join-code')?.value?.trim()||'';if(name.length<2)return authError('Enter your name.');if(!code)return authError('Enter your invite code.');try{localStorage.removeItem(TEST_MODE_KEY);setInviteAccessLocked(false);await joinWithInvite(name,code);context=await getContext();if(context?.profile?.role==='pending_parent'){localStorage.removeItem(PENDING_PARENT_PIN_KEY);setGateHtml('preapproval-pin','Choose the PIN you will use once your coach approves access. It will be saved to your account now.');return;}if(context?.profile?.role==='player'&&!context?.profile?.pin_set_at){setGateHtml('pinsetup','Create your 6-digit PIN for future player access.');return;}hideGate();window.dispatchEvent(new CustomEvent('valiants-authenticated',{detail:{source:'invite'}}));}catch(e){authError(e.message||String(e));}});
  }
  function escapeHtml(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function authError(msg){const el=document.getElementById('cloud-auth-error');if(el){el.textContent=msg;el.classList.remove('hidden');}const notice=document.getElementById('cloud-auth-notice');if(notice)notice.classList.add('hidden');}
  function showNotice(msg){const el=document.getElementById('cloud-auth-notice');if(el){el.textContent=msg;el.classList.remove('hidden');}const err=document.getElementById('cloud-auth-error');if(err)err.classList.add('hidden');}
  function hideGate(){document.getElementById('activation-gate')?.classList.add('hidden');document.body.classList.remove('auth-open');document.querySelector('.app-shell')?.classList.remove('account-locked');}
  async function signOut(event){
    try{event?.preventDefault?.();event?.stopPropagation?.();}catch{}
    const btn=event?.currentTarget instanceof HTMLElement?event.currentTarget:null;
    if(btn){btn.setAttribute('disabled','disabled');btn.textContent='Signing out…';}

    // Stop any account-specific work before clearing the active session.
    clearTimeout(saveTimer);saveTimer=null;pendingState=null;saving=false;
    clearInterval(pollTimer);pollTimer=null;
    try{if(window.__clubInboxTimer){clearInterval(window.__clubInboxTimer);window.__clubInboxTimer=null;}}catch{}
    try{if(window.__adminBackgroundTimer){clearInterval(window.__adminBackgroundTimer);window.__adminBackgroundTimer=null;}}catch{}
    try{if(window.__fixtureScanTimer){clearInterval(window.__fixtureScanTimer);window.__fixtureScanTimer=null;}}catch{}

    // Revoke the Supabase refresh session when possible. Local logout must still
    // complete if the device is offline or the server request fails.
    const accessToken=session?.access_token||'';
    if(accessToken){
      try{
        await fetch(base()+'/auth/v1/logout',{method:'POST',headers:authHeaders(accessToken)});
      }catch{}
    }

    localStorage.removeItem(TEST_MODE_KEY);
    clearInviteAccess();
    localStorage.removeItem(ACTIVE_TEAM_KEY);
    localStorage.removeItem(VERIFY_EMAIL_KEY);
    localStorage.removeItem(TEAM_DIRECTORY_CACHE_KEY);
    try{
      Object.keys(localStorage).forEach(k=>{
        if(k.startsWith(TEAM_STATE_CACHE_PREFIX))localStorage.removeItem(k);
      });
    }catch{}
    context=null;visibleTeams=[];activeTeam=null;activeRevision=-1;lastRemoteUpdatedAt='';

    // Lock the existing app immediately so no team data remains visible while
    // the clean reload is being prepared.
    try{document.querySelectorAll('dialog[open]').forEach(d=>d.close());}catch{}
    setGateHtml('join','Signed out.');
    window.dispatchEvent(new CustomEvent('valiants-signed-out'));

    // Reload without any auth callback/query fragments so bootstrap cannot
    // restore the session we just cleared.
    setTimeout(()=>{
      try{
        const clean=location.href.split('#')[0].split('?')[0];
        location.replace(clean);
      }catch{location.reload();}
    },120);
  }

  function updateCloudPanel(){
    const panel=document.getElementById('access-panel');if(!panel||!configured()||!context)return;
    if(testModeActive()){
      panel.classList.add('cloud-access-panel');
      const summary=document.getElementById('access-summary');if(summary)summary.textContent='Test Coach · U9 Valiants · local debug session';
      let controls=document.getElementById('cloud-account-controls');if(!controls){controls=document.createElement('div');controls.id='cloud-account-controls';controls.className='cloud-account-controls';panel.querySelector('.settings-accordion-body')?.appendChild(controls)||panel.appendChild(controls);}
      controls.innerHTML='<div class="cloud-account-row"><span><strong>TEST MODE</strong><small>Cloud writes disabled</small></span><button class="text-button" id="cloud-exit-test" type="button">Exit test mode</button></div>';
      document.getElementById('cloud-exit-test')?.addEventListener('click',e=>signOut(e));document.body.classList.add('cloud-enabled');return;
    }
    panel.classList.add('cloud-access-panel');
    const profile=context.profile||{};const t=currentTeam();const inviteAccess=profile.access_method==='invite'||session?.user?.user_metadata?.invite_access;
    const summary=document.getElementById('access-summary');
    const label=role()==='admin'?'Club Admin':role()==='assistant_coach'?'Assistant Coach':role()==='coach'?'Coach':role()==='player'?'Player':'Parent';
    if(summary)summary.textContent=`${profile.full_name||'Account'} · ${label}${t?' · '+t.ageGroup+' '+t.teamName:''}`;
    let controls=document.getElementById('cloud-account-controls');
    if(!controls){controls=document.createElement('div');controls.id='cloud-account-controls';controls.className='cloud-account-controls';panel.querySelector('.settings-accordion-body')?.appendChild(controls)||panel.appendChild(controls);}
    controls.innerHTML=`<div class="cloud-account-row"><span><strong>${escapeHtml(inviteAccess?(profile.full_name||'Invite access'):(session?.user?.email||profile.full_name||''))}</strong></span><div class="cloud-account-actions">${inviteAccess?'':`<button class="secondary-button compact" id="cloud-change-password">Change password</button>`}<button class="text-button" id="cloud-signout-settings" type="button">Sign out</button></div></div>`;
    document.getElementById('cloud-change-password')?.addEventListener('click',()=>setGateHtml('newpassword'));
    document.getElementById('cloud-signout-settings')?.addEventListener('click',e=>signOut(e));
    document.body.classList.add('cloud-enabled');
  }

  async function bootstrap(options={}){
    hooks=options||{};
    if(!configured()){document.body.classList.add('cloud-not-configured');return {configured:false};}
    document.body.classList.add('cloud-enabled');
    if(testModeActive()){
      context={profile:{user_id:'debug-user',club_id:'debug-club',team_id:TEST_TEAM.id,full_name:'Test Coach',role:'coach',access_method:'debug'},team:TEST_TEAM,club:{id:'debug-club',name:'Shooters Hill AFC'}};
      visibleTeams=[TEST_TEAM];activeTeam=TEST_TEAM;activeRevision=-1;
      hideGate();document.body.classList.add('debug-test-mode');
      if(!document.getElementById('test-mode-banner')){const b=document.createElement('div');b.id='test-mode-banner';b.className='test-mode-banner';b.textContent='TEST MODE · local data only · cloud writes disabled';document.body.prepend(b);}
      return {configured:true,role:'coach',profile:context.profile,club:context.club,team:oldShapeTeam(TEST_TEAM),teams:[oldShapeTeam(TEST_TEAM)],email:''};
    }
    if(INITIAL_AUTH_CALLBACK&&!initialAuthCallbackHandled){initialAuthCallbackHandled=true;const callbackType=await handleAuthCallback(INITIAL_AUTH_CALLBACK,{duringBootstrap:true});if(callbackType==='recovery'||callbackType==='error')return null;}
    const valid=await ensureFreshSession();
    if(!valid){setGateHtml('join');return null;}
    const teamCache=cachedTeams();
    let teamFetch=null;
    try{
      teamFetch=listTeams().catch(()=>teamCache);
      context=await getContext();
    }catch(e){saveSession(null);setGateHtml('join','Your saved access expired. Enter a new invite code.');return null;}
    if(!context?.profile){saveSession(null);setGateHtml('join','No club access was found for this device.');return null;}
    if(context.profile.role==='pending_parent'){
      if(!context.profile.pin_set_at&&pendingParentPin()){try{await setAccessPin(pendingParentPin());localStorage.removeItem(PENDING_PARENT_PIN_KEY);}catch{}}
      setGateHtml(context?.profile?.pin_set_at?'approval':'preapproval-pin',context?.profile?.pin_set_at?'PIN saved. Waiting for coach approval.':'Choose your 6-digit PIN now; it will work once approved.');return null;
    }
    if(context.profile.role==='parent'&&!context.profile.pin_set_at&&pendingParentPin()){try{await activatePendingParentPin();}catch{}}
    if(context.profile.role==='parent'&&(!context.profile.pin_set_at||context.profile.pin_reset_required)){setGateHtml('pinsetup',context.profile.pin_reset_required?'Your coach reset your PIN. Choose a new 6-digit PIN.':'Your access is approved. Create a 6-digit PIN for future sign-in.');return null;}
    if(context.profile.role==='player'&&!context.profile.pin_set_at){setGateHtml('pinsetup','Create a 6-digit PIN for future player sign-in.');return null;}
    if(context.profile.role==='revoked'){setGateHtml('revoked');return null;}
    if(context.profile.role==='pending'){saveSession(null);setGateHtml('join','Enter a current invite code to join a team.');return null;}
    if(teamCache.length){visibleTeams=teamCache;teamFetch?.then(rows=>{if(Array.isArray(rows)&&rows.length){visibleTeams=rows;}}).catch(()=>{});}else visibleTeams=await teamFetch;
    activeTeam=chooseActiveTeam(options.localState||null);
    if(!activeTeam){setGateHtml('join','No team is available to this account.');return null;}
    if(inviteAccessActive() && inviteAccessLocked()){setGateHtml('resume');return null;}
    hideGate();updateCloudPanel();
    return {configured:true,role:role(),profile:context.profile,club:context.club,team:oldShapeTeam(activeTeam),teams:visibleTeamList(),email:session?.user?.email||''};
  }

  async function loadInitialState(localState,seedFactory){
    if(testModeActive())return {state:localState,fromCloud:false,testMode:true};
    if(!configured()||!activeTeam)return {state:localState,fromCloud:false};
    const cached=cachedTeamState(activeTeam.id);
    if(cached?.state){
      activeRevision=Number(cached.revision??0);lastRemoteUpdatedAt=cached.updated_at||'';
      const cachedRevision=activeRevision;
      fetchTeamState(activeTeam.id).then(row=>{if(row?.state&&Number(row.revision)!==cachedRevision&&hooks.onRemoteState)hooks.onRemoteState(row.state,{reason:'background-refresh'});}).catch(()=>{});
      return {state:cached.state,fromCloud:true,cached:true,revision:activeRevision};
    }
    const row=await fetchTeamState(activeTeam.id);
    if(row?.state)return {state:row.state,fromCloud:true,revision:activeRevision};
    if(canEdit()){
      const seed=seedFactory?seedFactory(oldShapeTeam(activeTeam)):localState;
      activeRevision=-1;
      await saveTeamStateNow(seed);
      return {state:seed,fromCloud:false,created:true,revision:activeRevision};
    }
    return {state:localState,fromCloud:false};
  }
  function startPolling(){
    if(!configured()||!activeTeam)return;
    clearInterval(pollTimer);
    pollTimer=setInterval(()=>{if(document.visibilityState==='visible')pullLatest({quiet:true});},Math.max(15000,Number(cfg.syncIntervalMs||30000)));
    document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')pullLatest({quiet:true});});
  }

  window.ValiantsCloud={
    configured,bootstrap,loadInitialState,queueStateSave,pullLatest,startPolling,
    role,canEdit,canAdmin,assignedTeam,currentTeam,coachTeam,hasDualCoachAccess,visibleTeamList,createInvite,listTeamMembers,listClubCoaches,listClubAccessAccounts,removeClubCoach,listPublishedClubResults,listParentPlayerLinks,saveParentPlayerLinks,listPlayerAccountLinks,listMatchAvailability,saveMatchAvailability,listSelkentTeamDirectory,syncSelkentTeamDirectory,getCoachMatchNote,saveCoachMatchNote,listAnnouncements,createAnnouncement,markAnnouncementRead,deleteAnnouncement,listMatchAttendance,saveMatchAttendance,getAvailabilitySettings,setAvailabilityDeadline,sendAvailabilityReminder,listNotifications,markNotificationRead,notifyFixtureChange,notifySelectedSquad,notifyMatchReport,listPlayerAppearanceStats,resetParentPin,setAccessPin,approveParent,removeTeamMember,syncTeamDirectory,switchAdminTeam,getClubOverview,signOut,handleAuthCallback,
    updateCloudPanel,
    get context(){return context;},get session(){return session;},get revision(){return activeRevision;},get testMode(){return testModeActive();}
  };
})();

// v2.0.19: reliable Android custom-scheme recovery callback and verified Club Admin sign-in handoff.
// v2.0.20: Club Admin oversight workflow and secure Admin ↔ Coach inbox API.
// v2.0.21: in-process login handoff, Assistant Coach role, all-role inbox and background-only sync UI.

// v2.0.25: club-wide access management RPC.

// v2.0.27: approved-parent PIN access, RSVP and secure coaching notes.
// v2.0.28: parent-player linking, RSVP-driven squad readiness, fixture change details and matchday dashboard.

// v2.0.30: club announcements, match attendance, grouped admin health and pre-approval parent PIN choice.
// v2.0.31: U15 player access, shared availability, Selkent opponent directory, notifications-only communication and appearance themes.
// v2.0.32: weekly-cycle deadlines, notifications, appearance stats, calendar handoff and debug quick-login.

// v2.0.33: U15-only player app access guard.
