// Deployed live as Supabase Edge Function pin-login v1.
// Public endpoint with custom PIN authentication, 5-attempt lockout and 15-minute cooldown.
