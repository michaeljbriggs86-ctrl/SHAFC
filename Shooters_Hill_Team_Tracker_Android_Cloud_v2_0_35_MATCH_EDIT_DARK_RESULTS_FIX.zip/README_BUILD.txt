Shooters Hill Team Tracker Android Cloud v2.0.35

Android package
  com.shootershill.valiants

Version
  2.0.35 (versionCode 2035)

Build
  The GitHub Action extracts this ZIP and runs:
    gradle :app:assembleDebug

v2.0.32 highlights
- Debug-only Quick Test Login on the opening screen. It enters U9 Valiants Coach TEST MODE using local data only; cloud writes are disabled and the button is not available in release builds.
- Match availability deadlines are fixture-specific. Coaches can set a deadline and send reminders to outstanding linked parent/player accounts.
- New in-app notification centre with unread badge for club notices, availability requests/reminders, fixture changes, squad selection, access approval and completed match-report updates.
- Matchday squad can notify only linked accounts for selected players.
- Fixture changes create a read-only notification for parents/players as well as requiring coach reconfirmation.
- Attendance now drives season appearance statistics.
- U8-U11 attendance remains Present / Not present.
- U12+ completed-match attendance uses Started / Substitute / Unavailable / No-show so starts and appearances can be calculated accurately.
- Player profiles and the season contribution table now include appearances, attendance percentage and U12+ starts/sub appearances.
- Native Add to calendar action opens the device calendar pre-filled with opponent, kick-off, location, competition and kit note.
- Saving a completed match report notifies team parent/player accounts that updated stats and attendance are available.

Previous retained features
- U15-and-below read-only player accounts and shared parent/player availability response.
- Same-age Selkent opponent directory.
- Light / Dark / System appearance.
- Editable non-league Friendly/Tournament results.
- Club announcements and grouped Admin health dashboard.
- Parent PIN onboarding/reset and team dropdown login.
- Fixture-specific tactics, matchday dashboard and coach-controlled parent-player links.
- U12+ publication rule and mini-soccer score entry.


v2.0.33 changes
-----------------
- Club Admin Results now use the complete internal played-match history for every team/age, including friendlies, tournaments and Mini-Soccer scores that Selkent does not publish.
- Coach/Assistant Coach Club Results remain restricted to Selkent-published results (U12+).
- Player app access/invites are restricted to U15 squads only in both UI and Supabase functions.
- Dark-mode contrast hardened across forms, labels, match cards, tabs, tables, notifications and secondary text.


v2.0.34 changes
- Season archive and Club Admin rollover with read-only archived season viewer.
- Audit history for key match, attendance, access, fixture and tactics changes.
- Proper tournament event mode with tournament squad, grouped games and event W/D/L GF/GA.


v2.0.35 changes
- Restored Add match button on Matches.
- Scheduled match cards now expose Edit fixture.
- Admin Results no longer re-renders Club at a glance underneath age-group results.
- Expanded dark-mode contrast coverage across match details, admin cards, status pills, tables and secondary text.
